import React, { Component } from 'react'
import "./Header.css"
export default class Header extends Component {
  render() {
    return (
      <div>
        <h1 className='header'>Header</h1>
      </div>
    )
  }
}

